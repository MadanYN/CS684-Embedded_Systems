Assumptions made:
	Five sensor integer input
	Four output streams namely plot_midnode, node, velocity of right wheel and velocity of left wheel
	We have designed the code explicitly for the path given in the problem statement, so we have statically defined the nodes and the midnode-plot pair in an array and we are giving the output flows in sqequence accordingly. 
	We have kept the values of the constants of pid controller as all ones for now. This can be tuned once we deploy the code on hardware
